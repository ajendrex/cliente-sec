# Cliente SEC

Este paquete contiene la clase `ClienteSEC`, con la cuál podrás iniciar una sesión http
de un usuario registrado en http://www.sec.cl/ y descargar información relacionada a inscripciones
registradas en dicho sitio web.

